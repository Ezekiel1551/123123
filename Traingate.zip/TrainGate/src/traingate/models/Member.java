package traingate.models;

import java.util.Date;

/**
 * Member class representing a gym member.
 * Updated to include membership tiers and perks.
 */
public class Member extends User {
    private String memberId;
    private String contactNumber;
    private String membershipType; // Monthly, Yearly
    private Date membershipStart;
    private Date membershipExpiry;
    private boolean isActive;

    // --- New Tier and Perk Fields ---
    private String membershipTier; // Normal, VIP
    private boolean has247Access;
    private int ptSessionsRemaining;
    private int bodyCompositionScansRemaining;
    private boolean hasMealPlanDiscount;

    /**
     * Constructor for CREATING a NEW member.
     * This sets default perks based on the chosen tier.
     */
    public Member(String username, String password, String fullName, String memberId, 
                  String contactNumber, String membershipType, String membershipTier) {
        super(username, password, fullName);
        this.memberId = memberId;
        this.contactNumber = contactNumber;
        this.membershipType = membershipType;
        this.membershipTier = membershipTier;
        
        this.membershipStart = new Date();
        this.isActive = true;
        
        // Set default perks based on the tier
        setPerksForTier(membershipTier);
        
        // Calculate expiry date
        calculateExpiryDate();
    }
    
    /**
     * Constructor for LOADING an EXISTING member from the database.
     * Perks and dates will be set via setters.
     */
    public Member(String username, String password, String fullName, String memberId, 
                  String contactNumber, String membershipType) {
        super(username, password, fullName);
        this.memberId = memberId;
        this.contactNumber = contactNumber;
        this.membershipType = membershipType;
    }

    /**
     * Helper method to set default perks when a new member is created.
     */
    private void setPerksForTier(String tier) {
        if ("VIP".equals(tier)) {
            this.has247Access = true;
            this.ptSessionsRemaining = 5; // 5 free sessions
            this.bodyCompositionScansRemaining = 2; // 2 free scans
            this.hasMealPlanDiscount = true;
        } else {
            // "Normal" tier defaults
            this.has247Access = false;
            this.ptSessionsRemaining = 0;
            this.bodyCompositionScansRemaining = 0;
            this.hasMealPlanDiscount = false;
        }
    }

    // Unchanged method
    private void calculateExpiryDate() {
        long currentTime = membershipStart.getTime();
        long daysInMillis = 24 * 60 * 60 * 1000;
        
        switch (membershipType) {
            case "Monthly":
                membershipExpiry = new Date(currentTime + (30 * daysInMillis));
                break;
            case "Quarterly":
                membershipExpiry = new Date(currentTime + (90 * daysInMillis));
                break;
            case "Yearly":
                membershipExpiry = new Date(currentTime + (365 * daysInMillis));
                break;
            default:
                membershipExpiry = new Date(currentTime + (30 * daysInMillis));
        }
    }

    // --- Getters and Setters (Includes new ones) ---
    
    @Override
    public String getUserType() {
        return "Member";
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getMembershipType() {
        return membershipType;
    }

    public void setMembershipType(String membershipType) {
        this.membershipType = membershipType;
        calculateExpiryDate();
    }

    public Date getMembershipStart() {
        return membershipStart;
    }

    public void setMembershipStart(Date membershipStart) {
        this.membershipStart = membershipStart;
    }

    public Date getMembershipExpiry() {
        return membershipExpiry;
    }

    public void setMembershipExpiry(Date membershipExpiry) {
        this.membershipExpiry = membershipExpiry;
    }

    public boolean isActive() {
        Date now = new Date();
        return isActive && now.before(membershipExpiry);
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    // --- New Getters/Setters for Perks ---

    public String getMembershipTier() {
        return membershipTier;
    }

    public void setMembershipTier(String membershipTier) {
        this.membershipTier = membershipTier;
    }

    public boolean has247Access() {
        return has247Access;
    }

    public void setHas247Access(boolean has247Access) {
        this.has247Access = has247Access;
    }

    public int getPtSessionsRemaining() {
        return ptSessionsRemaining;
    }

    public void setPtSessionsRemaining(int ptSessionsRemaining) {
        this.ptSessionsRemaining = ptSessionsRemaining;
    }

    public int getBodyCompositionScansRemaining() {
        return bodyCompositionScansRemaining;
    }

    public void setBodyCompositionScansRemaining(int bodyCompositionScansRemaining) {
        this.bodyCompositionScansRemaining = bodyCompositionScansRemaining;
    }

    public boolean hasMealPlanDiscount() {
        return hasMealPlanDiscount;
    }

    public void setHasMealPlanDiscount(boolean hasMealPlanDiscount) {
        this.hasMealPlanDiscount = hasMealPlanDiscount;
    }

    // This toString() is now only used for debugging, not saving.
    @Override
    public String toString() {
        return memberId + "," + getUsername() + "," + getFullName() + "," + membershipTier;
    }
}