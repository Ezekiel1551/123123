package traingate.models;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Transaction class to record all gym transactions.
 * Demonstrates encapsulation and data structure usage.
 */
public class Transaction {
    private String transactionId;
    private String memberId;
    private String transactionType;
    private double amount;
    private Date transactionDate;
    private String description;
    
    public Transaction(String transactionId, String memberId, String transactionType, 
                      double amount, String description) {
        this.transactionId = transactionId;
        this.memberId = memberId;
        this.transactionType = transactionType;
        this.amount = amount;
        this.transactionDate = new Date();
        this.description = description;
    }
    
    // Getters and setters
    public String getTransactionId() {
        return transactionId;
    }
    
    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }
    
    public String getMemberId() {
        return memberId;
    }
    
    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }
    
    public String getTransactionType() {
        return transactionType;
    }
    
    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }
    
    public double getAmount() {
        return amount;
    }
    
    public void setAmount(double amount) {
        this.amount = amount;
    }
    
    public Date getTransactionDate() {
        return transactionDate;
    }
    
    public void setTransactionDate(Date transactionDate) {
        this.transactionDate = transactionDate;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getFormattedDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(transactionDate);
    }
    
    @Override
    public String toString() {
        return transactionId + "," + memberId + "," + transactionType + "," + 
               amount + "," + transactionDate.getTime() + "," + description;
    }
}
