package traingate.models;

/**
 * Admin class representing a system administrator.
 * Demonstrates inheritance and method overriding (Polymorphism).
 */
public class Admin extends User {
    private String adminId;
    
    public Admin(String username, String password, String fullName, String adminId) {
        super(username, password, fullName);
        this.adminId = adminId;
    }
    
    @Override
    public String getUserType() {
        return "Admin";
    }
    
    public String getAdminId() {
        return adminId;
    }
    
    public void setAdminId(String adminId) {
        this.adminId = adminId;
    }
}
