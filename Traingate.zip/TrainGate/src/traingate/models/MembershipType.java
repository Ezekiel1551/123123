package traingate.models;

/**
 * Utility class to manage membership types and pricing.
 * This now includes logic for different Tiers.
 */
public class MembershipType {
    
    // Membership duration types
    public static String[] getAllTypes() {
        return new String[]{"Monthly", "Quarterly", "Yearly"};
    }
    
    /**
     * Gets the price based on both the duration (type) and the tier (Normal/VIP).
     * @param type Monthly, Quarterly, or Yearly
     * @param tier Normal or VIP
     * @return The price as a double
     */
    public static double getPrice(String type, String tier) {
        double basePrice;
        
        switch (type) {
            case "Monthly":
                basePrice = 1500.00;
                break;
            case "Quarterly":
                basePrice = 4000.00;
                break;
            case "Yearly":
                basePrice = 15000.00;
                break;
            default:
                basePrice = 1500.00;
        }
        
        // VIP tier has a 50% markup (example)
        if ("VIP".equals(tier)) {
            return basePrice * 1.5;
        }
        
        return basePrice;
    }
}