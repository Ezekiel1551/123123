package traingate.gui;

import traingate.models.*;
import traingate.utils.DataManager;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * LoginFrame - Main login window for the application.
 * Demonstrates Java Swing GUI components and event handling.
 */
public class LoginFrame extends JFrame {
    private static final long serialVersionUID = 1L;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JComboBox<String> userTypeCombo;
    private JButton loginButton;
    private JButton registerButton;
    private DataManager dataManager;
    
    public LoginFrame() {
        dataManager = DataManager.getInstance();
        initComponents();
    }
    
    private void initComponents() {
        setTitle("TrainGate - Gym Management System");
        setSize(450, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        
        // Main panel
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBackground(new Color(240, 240, 240));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Title panel
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(new Color(41, 128, 185));
        JLabel titleLabel = new JLabel("TrainGate Login");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);
        titlePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(20, 30, 20, 30)
        ));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // User Type
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new JLabel("Login As:"), gbc);
        
        gbc.gridx = 1;
        String[] userTypes = {"Admin", "Member"};
        userTypeCombo = new JComboBox<>(userTypes);
        formPanel.add(userTypeCombo, gbc);
        
        // Username
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(new JLabel("Username:"), gbc);
        
        gbc.gridx = 1;
        usernameField = new JTextField(20);
        usernameField.setForeground(Color.BLACK);
        formPanel.add(usernameField, gbc);
        
        // Password
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(new JLabel("Password:"), gbc);
        
        gbc.gridx = 1;
        passwordField = new JPasswordField(20);
        passwordField.setForeground(Color.BLACK);
        formPanel.add(passwordField, gbc);
        
        // Buttons panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        
        loginButton = new JButton("Login");
        loginButton.setBackground(new Color(41, 128, 185));
        loginButton.setForeground(Color.BLACK);
        loginButton.setFont(new Font("Arial", Font.BOLD, 14));
        loginButton.setFocusPainted(false);
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleLogin();
            }
        });
        
        registerButton = new JButton("Register New Member");
        registerButton.setBackground(new Color(46, 204, 113));
        registerButton.setForeground(Color.BLACK);
        registerButton.setFont(new Font("Arial", Font.BOLD, 14));
        registerButton.setFocusPainted(false);
        registerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                openRegisterFrame();
            }
        });
        
        buttonPanel.add(loginButton);
        buttonPanel.add(registerButton);
        
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        formPanel.add(buttonPanel, gbc);
        
        // Add panels to frame
        mainPanel.add(titlePanel, BorderLayout.NORTH);
        mainPanel.add(formPanel, BorderLayout.CENTER);
        
        add(mainPanel);
        
        // Enter key to login
        passwordField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleLogin();
            }
        });
    }
    
    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        String userType = (String) userTypeCombo.getSelectedItem();
        
        // Validation
        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please enter username and password", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        try {
            if (userType.equals("Admin")) {
                if (dataManager.validateAdminLogin(username, password)) {
                    JOptionPane.showMessageDialog(this, 
                        "Admin login successful!", 
                        "Success", 
                        JOptionPane.INFORMATION_MESSAGE);
                    openAdminDashboard();
                } else {
                    JOptionPane.showMessageDialog(this, 
                        "Invalid admin credentials", 
                        "Error", 
                        JOptionPane.ERROR_MESSAGE);
                }
            } else {
                if (dataManager.validateMemberLogin(username, password)) {
                    Member member = dataManager.getMemberByUsername(username);
                    if (member.isActive()) {
                        JOptionPane.showMessageDialog(this, 
                            "Welcome back, " + member.getFullName() + "!", 
                            "Success", 
                            JOptionPane.INFORMATION_MESSAGE);
                        openMemberDashboard(member);
                    } else {
                        JOptionPane.showMessageDialog(this, 
                            "Your membership has expired. Please contact admin.", 
                            "Error", 
                            JOptionPane.WARNING_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(this, 
                        "Invalid member credentials", 
                        "Error", 
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, 
                "An error occurred: " + ex.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void openAdminDashboard() {
        AdminDashboard dashboard = new AdminDashboard();
        dashboard.setVisible(true);
        this.dispose();
    }
    
    private void openMemberDashboard(Member member) {
        MemberDashboard dashboard = new MemberDashboard(member);
        dashboard.setVisible(true);
        this.dispose();
    }
    
    private void openRegisterFrame() {
        RegisterMemberFrame registerFrame = new RegisterMemberFrame(this);
        registerFrame.setVisible(true);
    }
}
