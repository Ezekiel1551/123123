package traingate.gui;

import traingate.models.*;
import traingate.utils.DataManager;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener; // <-- Import is included

/**
 * RegisterMemberFrame - GUI for adding a new member.
 * Updated to include Membership Tiers and automatic payment transaction.
 */
public class RegisterMemberFrame extends JFrame {
    private static final long serialVersionUID = 1L;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JTextField fullNameField;
    private JTextField contactField;
    private JComboBox<String> membershipTypeBox;
    private JComboBox<String> membershipTierBox; // New Tier dropdown
    private JLabel priceLabel; // Shows the price
    private DataManager dataManager;

    public RegisterMemberFrame(LoginFrame owner) {
        dataManager = DataManager.getInstance();
        
        setTitle("Register New Member");
        setSize(450, 450);
        setLocationRelativeTo(owner);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        // Main panel with grid layout
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Helper label
        JLabel titleLabel = new JLabel("New Member Registration");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy = 0;
        mainPanel.add(titleLabel, gbc);

        // --- Form Fields ---
        gbc.gridwidth = 1;
        gbc.gridy++;
        gbc.gridx = 0;
        mainPanel.add(new JLabel("Full Name:"), gbc);
        fullNameField = new JTextField(20);
        gbc.gridx = 1;
        mainPanel.add(fullNameField, gbc);

        gbc.gridy++;
        gbc.gridx = 0;
        mainPanel.add(new JLabel("Username:"), gbc);
        usernameField = new JTextField(20);
        gbc.gridx = 1;
        mainPanel.add(usernameField, gbc);

        gbc.gridy++;
        gbc.gridx = 0;
        mainPanel.add(new JLabel("Password:"), gbc);
        passwordField = new JPasswordField(20);
        gbc.gridx = 1;
        mainPanel.add(passwordField, gbc);

        gbc.gridy++;
        gbc.gridx = 0;
        mainPanel.add(new JLabel("Contact Number:"), gbc);
        contactField = new JTextField(20);
        gbc.gridx = 1;
        mainPanel.add(contactField, gbc);

        gbc.gridy++;
        gbc.gridx = 0;
        mainPanel.add(new JLabel("Membership Type:"), gbc);
        membershipTypeBox = new JComboBox<>(MembershipType.getAllTypes());
        gbc.gridx = 1;
        mainPanel.add(membershipTypeBox, gbc);

        // --- New Tier Field ---
        gbc.gridy++;
        gbc.gridx = 0;
        mainPanel.add(new JLabel("Membership Tier:"), gbc);
        membershipTierBox = new JComboBox<>(new String[]{"Normal", "VIP"});
        gbc.gridx = 1;
        mainPanel.add(membershipTierBox, gbc);

        // --- Price Label ---
        gbc.gridy++;
        gbc.gridx = 0;
        priceLabel = new JLabel("Price: ₱0.00");
        priceLabel.setFont(new Font("Arial", Font.BOLD, 14));
        priceLabel.setForeground(new Color(0, 100, 0));
        gbc.gridx = 1;
        mainPanel.add(priceLabel, gbc);

        // --- Register Button ---
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        JButton registerButton = new JButton("Register Member");
        registerButton.setBackground(new Color(46, 204, 113));
        registerButton.setForeground(Color.BLACK);
        registerButton.setFont(new Font("Arial", Font.BOLD, 14));
        mainPanel.add(registerButton, gbc);

        // --- Action Listeners ---
        
        // Listener to update price dynamically
        ActionListener priceUpdater = e -> updatePrice();
        membershipTypeBox.addActionListener(priceUpdater);
        membershipTierBox.addActionListener(priceUpdater);

        // Main register button listener
        registerButton.addActionListener(e -> registerMember());

        // Initialize price
        updatePrice();
        
        add(mainPanel);
    }

    /**
     * Updates the price label based on selections.
     */
    private void updatePrice() {
        String type = (String) membershipTypeBox.getSelectedItem();
        String tier = (String) membershipTierBox.getSelectedItem();
        double price = MembershipType.getPrice(type, tier);
        priceLabel.setText(String.format("Price: ₱%.2f", price));
    }

    /**
     * Handles the member registration logic.
     */
    private void registerMember() {
        String fullName = fullNameField.getText();
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        String contact = contactField.getText();
        String memberType = (String) membershipTypeBox.getSelectedItem();
        String memberTier = (String) membershipTierBox.getSelectedItem();
        
        if (fullName.isEmpty() || username.isEmpty() || password.isEmpty() || contact.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Check if username already exists
        if (dataManager.getMemberByUsername(username) != null || dataManager.validateAdminLogin(username, password)) {
            JOptionPane.showMessageDialog(this, "Username already exists.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // 1. Generate new IDs
            String memberId = dataManager.generateMemberId();
            String transactionId = dataManager.generateTransactionId();
            
            // 2. Create the new Member object
            Member newMember = new Member(
                username, password, fullName, memberId, 
                contact, memberType, memberTier
            );
            
            // 3. Get the price for this registration
            double amount = MembershipType.getPrice(memberType, memberTier);
            
            // 4. Create the initial payment transaction
            Transaction transaction = new Transaction(
                transactionId,
                memberId,
                "Payment", // This is a new payment
                amount,
                "New member registration - " + memberTier + " " + memberType
            );
            
            // 5. Add the member AND the transaction
            boolean memberAdded = dataManager.addMember(newMember);
            boolean transactionAdded = dataManager.addTransaction(transaction);
            
            if (memberAdded && transactionAdded) {
                JOptionPane.showMessageDialog(this, 
                    "Member registered successfully!\nMember ID: " + memberId, 
                    "Success", 
                    JOptionPane.INFORMATION_MESSAGE);
                this.dispose(); // Close the registration window
            } else {
                throw new Exception("Failed to save member or transaction to database.");
            }
            
        } catch (Exception e) {
            // --- THIS IS THE FIXED BLOCK ---
            JOptionPane.showMessageDialog(this, 
                "Error during registration: " + e.getMessage(), 
                "Registration Error", 
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}