package traingate.gui;

import traingate.models.*;
import traingate.utils.DataManager;
import traingate.utils.DatabaseManager; // Import DatabaseManager for the new dialog

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

/**
 * AdminDashboard - Main dashboard for administrators.
 * Updated to show Membership Tier and manage Member Perks.
 */
public class AdminDashboard extends JFrame {
    private static final long serialVersionUID = 1L;
    private DataManager dataManager;
    private JTable membersTable;
    private JTable transactionsTable;
    private DefaultTableModel membersModel;
    private DefaultTableModel transactionsModel;
    private JLabel totalMembersLabel;
    private JLabel totalRevenueLabel;
    private JTabbedPane tabbedPane;
    
    public AdminDashboard() {
        dataManager = DataManager.getInstance();
        initComponents();
        loadData();
    }
    
    private void initComponents() {
        setTitle("TrainGate - Admin Dashboard");
        setSize(1000, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Main panel
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBackground(new Color(240, 240, 240));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Header panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(41, 128, 185));
        headerPanel.setLayout(new BorderLayout());
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel titleLabel = new JLabel("Admin Dashboard");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        
        JButton logoutButton = new JButton("Logout");
        logoutButton.setBackground(new Color(231, 76, 60));
        logoutButton.setForeground(Color.BLACK);
        logoutButton.setFont(new Font("Arial", Font.BOLD, 12));
        logoutButton.setFocusPainted(false);
        logoutButton.addActionListener(e -> logout());
        
        headerPanel.add(titleLabel, BorderLayout.WEST);
        headerPanel.add(logoutButton, BorderLayout.EAST);
        
        // Stats panel
        JPanel statsPanel = new JPanel();
        statsPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 30, 10));
        statsPanel.setBackground(Color.WHITE);
        statsPanel.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        
        totalMembersLabel = new JLabel("Total Members: 0");
        totalMembersLabel.setFont(new Font("Arial", Font.BOLD, 16));
        
        totalRevenueLabel = new JLabel("Total Revenue: ₱0.00");
        totalRevenueLabel.setFont(new Font("Arial", Font.BOLD, 16));
        
        statsPanel.add(totalMembersLabel);
        statsPanel.add(totalRevenueLabel);
        
        // Tabbed pane
        tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Arial", Font.BOLD, 14));
        
        // Members tab
        JPanel membersPanel = createMembersPanel();
        tabbedPane.addTab("Members", membersPanel);
        
        // Transactions tab
        JPanel transactionsPanel = createTransactionsPanel();
        tabbedPane.addTab("Transactions", transactionsPanel);
        
        // Add to main panel
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        JPanel containerPanel = new JPanel(new BorderLayout());
        containerPanel.add(statsPanel, BorderLayout.NORTH);
        containerPanel.add(tabbedPane, BorderLayout.CENTER);
        
        mainPanel.add(containerPanel, BorderLayout.CENTER);
        
        add(mainPanel);
    }
    
    private JPanel createMembersPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout(5, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        
        JButton addMemberButton = new JButton("Add New Member");
        addMemberButton.setBackground(new Color(46, 204, 113));
        addMemberButton.setForeground(Color.BLACK);
        addMemberButton.setFont(new Font("Arial", Font.BOLD, 12));
        addMemberButton.addActionListener(e -> openRegisterFrame());
        
        JButton renewButton = new JButton("Renew Membership");
        renewButton.setBackground(new Color(52, 152, 219));
        renewButton.setForeground(Color.BLACK);
        renewButton.setFont(new Font("Arial", Font.BOLD, 12));
        renewButton.addActionListener(e -> renewMembership());
        
        // --- New "Manage Perks" Button ---
        JButton managePerksButton = new JButton("Manage Perks");
        managePerksButton.setBackground(new Color(243, 156, 18)); // Orange
        managePerksButton.setForeground(Color.BLACK);
        managePerksButton.setFont(new Font("Arial", Font.BOLD, 12));
        managePerksButton.addActionListener(e -> openManagePerksDialog());
        
        JButton deleteMemberButton = new JButton("Delete Member");
        deleteMemberButton.setBackground(new Color(231, 76, 60));
        deleteMemberButton.setForeground(Color.BLACK);
        deleteMemberButton.setFont(new Font("Arial", Font.BOLD, 12));
        deleteMemberButton.addActionListener(e -> deleteMember());
        
        JButton refreshButton = new JButton("Refresh");
        refreshButton.setBackground(new Color(149, 165, 166));
        refreshButton.setForeground(Color.BLACK);
        refreshButton.setFont(new Font("Arial", Font.BOLD, 12));
        refreshButton.addActionListener(e -> loadData());
        
        buttonPanel.add(addMemberButton);
        buttonPanel.add(renewButton);
        buttonPanel.add(managePerksButton); // Add new button
        buttonPanel.add(deleteMemberButton);
        buttonPanel.add(refreshButton);
        
        // Table - Added "Tier" column
        String[] columns = {"Member ID", "Name", "Username", "Contact", "Type", "Tier", "Status", "Expiry"};
        membersModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        membersTable = new JTable(membersModel);
        membersTable.setRowHeight(25);
        
        JScrollPane scrollPane = new JScrollPane(membersTable);
        
        panel.add(buttonPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createTransactionsPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout(5, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        
        JButton refreshButton = new JButton("Refresh");
        refreshButton.setBackground(new Color(149, 165, 166));
        refreshButton.setForeground(Color.BLACK);
        refreshButton.setFont(new Font("Arial", Font.BOLD, 12));
        refreshButton.addActionListener(e -> loadData());
        
        buttonPanel.add(refreshButton);
        
        // Table
        String[] columns = {"Transaction ID", "Member ID", "Type", "Amount", "Date", "Description"};
        transactionsModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        transactionsTable = new JTable(transactionsModel);
        transactionsTable.setRowHeight(25);
        
        JScrollPane scrollPane = new JScrollPane(transactionsTable);
        
        panel.add(buttonPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        return panel;
    }
    
    private void loadData() {
        // Clear tables
        membersModel.setRowCount(0);
        transactionsModel.setRowCount(0);
        
        // Load members
        ArrayList<Member> members = dataManager.getAllMembers();
        for (Member m : members) {
            String status = m.isActive() ? "Active" : "Expired";
            String expiry = new java.text.SimpleDateFormat("yyyy-MM-dd").format(m.getMembershipExpiry());
            
            // Add new "Tier" data to the row
            membersModel.addRow(new Object[]{
                m.getMemberId(),
                m.getFullName(),
                m.getUsername(),
                m.getContactNumber(),
                m.getMembershipType(),
                m.getMembershipTier(), // New column
                status,
                expiry
            });
        }
        
        // Load transactions
        ArrayList<Transaction> transactions = dataManager.getAllTransactions();
        for (Transaction t : transactions) {
            transactionsModel.addRow(new Object[]{
                t.getTransactionId(),
                t.getMemberId(),
                t.getTransactionType(),
                "₱" + String.format("%.2f", t.getAmount()),
                t.getFormattedDate(),
                t.getDescription()
            });
        }
        
        // Update stats
        totalMembersLabel.setText("Total Members: " + members.size());
        totalRevenueLabel.setText("Total Revenue: ₱" + String.format("%.2f", dataManager.calculateTotalRevenue()));
    }
    
    private void openRegisterFrame() {
        LoginFrame tempFrame = new LoginFrame();
        RegisterMemberFrame registerFrame = new RegisterMemberFrame(tempFrame);
        registerFrame.setVisible(true);
        registerFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                loadData();
            }
        });
    }
    
    private void renewMembership() {
        int selectedRow = membersTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a member to renew", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String memberId = (String) membersModel.getValueAt(selectedRow, 0);
        Member member = dataManager.getMember(memberId);
        String currentTier = member.getMembershipTier(); // Get member's current tier
        
        String[] types = MembershipType.getAllTypes();
        String selectedType = (String) JOptionPane.showInputDialog(this,
            "Select new membership type for " + member.getFullName(),
            "Renew Membership",
            JOptionPane.QUESTION_MESSAGE,
            null,
            types,
            member.getMembershipType());
        
        if (selectedType != null) {
            // Get price based on their CURRENT tier and NEW duration
            double amount = MembershipType.getPrice(selectedType, currentTier);
            
            // Update member object
            member.setMembershipType(selectedType);
            member.setActive(true);
            
            String transactionId = dataManager.generateTransactionId();
            Transaction transaction = new Transaction(
                transactionId,
                memberId,
                "Renewal",
                amount,
                "Membership renewal - " + currentTier + " " + selectedType
            );
            dataManager.addTransaction(transaction);
            
            JOptionPane.showMessageDialog(this,
                "Membership renewed successfully!\nAmount: ₱" + String.format("%.2f", amount),
                "Success",
                JOptionPane.INFORMATION_MESSAGE);
            
            loadData();
        }
    }
    
    /**
     * --- New Method ---
     * Opens a dialog to manage a selected member's perks.
     */
    private void openManagePerksDialog() {
        int selectedRow = membersTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a member to manage.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String memberId = (String) membersModel.getValueAt(selectedRow, 0);
        Member member = dataManager.getMember(memberId);

        // --- Create a new dialog for managing perks ---
        JDialog manageDialog = new JDialog(this, "Manage Perks: " + member.getFullName(), true);
        manageDialog.setSize(450, 350);
        manageDialog.setLocationRelativeTo(this);
        manageDialog.setLayout(new GridBagLayout());
        manageDialog.getRootPane().setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        manageDialog.add(new JLabel("Membership Tier:"), gbc);
        
        gbc.gridx = 1;
        JComboBox<String> tierBox = new JComboBox<>(new String[]{"Normal", "VIP"});
        tierBox.setSelectedItem(member.getMembershipTier());
        manageDialog.add(tierBox, gbc);

        gbc.gridy++;
        gbc.gridx = 0;
        manageDialog.add(new JLabel("PT Sessions Remaining:"), gbc);
        
        gbc.gridx = 1;
        JSpinner ptSpinner = new JSpinner(new SpinnerNumberModel(member.getPtSessionsRemaining(), 0, 100, 1));
        manageDialog.add(ptSpinner, gbc);

        gbc.gridy++;
        gbc.gridx = 0;
        manageDialog.add(new JLabel("Body Comp Scans:"), gbc);
        
        gbc.gridx = 1;
        JSpinner bcSpinner = new JSpinner(new SpinnerNumberModel(member.getBodyCompositionScansRemaining(), 0, 100, 1));
        manageDialog.add(bcSpinner, gbc);

        gbc.gridy++;
        gbc.gridx = 0;
        manageDialog.add(new JLabel("24/7 Access:"), gbc);
        
        gbc.gridx = 1;
        JCheckBox accessCheck = new JCheckBox();
        accessCheck.setSelected(member.has247Access());
        manageDialog.add(accessCheck, gbc);

        gbc.gridy++;
        gbc.gridx = 0;
        manageDialog.add(new JLabel("Meal Plan Discount:"), gbc);
        
        gbc.gridx = 1;
        JCheckBox mealCheck = new JCheckBox();
        mealCheck.setSelected(member.hasMealPlanDiscount());
        manageDialog.add(mealCheck, gbc);
        
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;
        JButton saveButton = new JButton("Save Changes");
        saveButton.setBackground(new Color(46, 204, 113));
        saveButton.setFont(new Font("Arial", Font.BOLD, 12));
        
        manageDialog.add(saveButton, gbc);

        saveButton.addActionListener(e -> {
            // Get values from the form
            String newTier = (String) tierBox.getSelectedItem();
            int newPtSessions = (int) ptSpinner.getValue();
            int newBcScans = (int) bcSpinner.getValue();
            boolean newAccess = accessCheck.isSelected();
            boolean newMealPlan = mealCheck.isSelected();

            // Update the local member object
            member.setMembershipTier(newTier);
            member.setPtSessionsRemaining(newPtSessions);
            member.setBodyCompositionScansRemaining(newBcScans);
            member.setHas247Access(newAccess);
            member.setHasMealPlanDiscount(newMealPlan);

            // Save to database using the DataManager
            if (dataManager.updateMemberPerks(member)) {
                JOptionPane.showMessageDialog(manageDialog, "Perks updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                manageDialog.dispose();
                loadData(); // Refresh the main table
            } else {
                JOptionPane.showMessageDialog(manageDialog, "Failed to update perks.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        manageDialog.setVisible(true);
    }
    
    private void deleteMember() {
        int selectedRow = membersTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a member to delete", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String memberId = (String) membersModel.getValueAt(selectedRow, 0);
        String memberName = (String) membersModel.getValueAt(selectedRow, 1);
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete member:\n" + 
            memberName + " (ID: " + memberId + ")?\n\n" +
            "This will also delete all their transactions!",
            "Confirm Delete",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            boolean success = dataManager.deleteMember(memberId);
            
            if (success) {
                JOptionPane.showMessageDialog(this, "Member deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                loadData(); // This will now show correct revenue
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete member.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void logout() {
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to logout?", "Confirm Logout", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            LoginFrame loginFrame = new LoginFrame();
            loginFrame.setVisible(true);
            this.dispose();
        }
    }
}