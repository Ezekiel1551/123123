package traingate.gui;

import traingate.models.*;
import traingate.utils.DataManager;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

/**
 * MemberDashboard - Dashboard for gym members.
 * Demonstrates data display and user-specific views.
 */
public class MemberDashboard extends JFrame {
    private static final long serialVersionUID = 1L;
    private Member currentMember;
    private DataManager dataManager;
    private JLabel nameLabel;
    private JLabel memberIdLabel;
    private JLabel membershipTypeLabel;
    private JLabel statusLabel;
    private JLabel expiryLabel;
    private JTable transactionsTable;
    private DefaultTableModel transactionsModel;
    
    public MemberDashboard(Member member) {
        this.currentMember = member;
        this.dataManager = DataManager.getInstance();
        initComponents();
        loadData();
    }
    
    private void initComponents() {
        setTitle("TrainGate - Member Dashboard");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Main panel
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBackground(new Color(240, 240, 240));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Header panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(46, 204, 113));
        headerPanel.setLayout(new BorderLayout());
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel titleLabel = new JLabel("Member Dashboard");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        
        JButton logoutButton = new JButton("Logout");
        logoutButton.setBackground(new Color(231, 76, 60));
        logoutButton.setForeground(Color.BLACK);
        logoutButton.setFont(new Font("Arial", Font.BOLD, 12));
        logoutButton.setFocusPainted(false);
        logoutButton.addActionListener(e -> logout());
        
        headerPanel.add(titleLabel, BorderLayout.WEST);
        headerPanel.add(logoutButton, BorderLayout.EAST);
        
        // Profile panel
        JPanel profilePanel = new JPanel();
        profilePanel.setLayout(new GridBagLayout());
        profilePanel.setBackground(Color.WHITE);
        profilePanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            "My Profile",
            0,
            0,
            new Font("Arial", Font.BOLD, 16)
        ));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 20, 10, 20);
        gbc.anchor = GridBagConstraints.WEST;
        
        nameLabel = new JLabel();
        nameLabel.setFont(new Font("Arial", Font.BOLD, 18));
        
        memberIdLabel = new JLabel();
        memberIdLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        
        membershipTypeLabel = new JLabel();
        membershipTypeLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        
        statusLabel = new JLabel();
        statusLabel.setFont(new Font("Arial", Font.BOLD, 14));
        
        expiryLabel = new JLabel();
        expiryLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        profilePanel.add(new JLabel("Name: "), gbc);
        gbc.gridx = 1;
        profilePanel.add(nameLabel, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 1;
        profilePanel.add(new JLabel("Member ID: "), gbc);
        gbc.gridx = 1;
        profilePanel.add(memberIdLabel, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 2;
        profilePanel.add(new JLabel("Membership Type: "), gbc);
        gbc.gridx = 1;
        profilePanel.add(membershipTypeLabel, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 3;
        profilePanel.add(new JLabel("Status: "), gbc);
        gbc.gridx = 1;
        profilePanel.add(statusLabel, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 4;
        profilePanel.add(new JLabel("Membership Expiry: "), gbc);
        gbc.gridx = 1;
        profilePanel.add(expiryLabel, gbc);
        
        // Transactions panel
        JPanel transactionsPanel = new JPanel();
        transactionsPanel.setLayout(new BorderLayout(5, 5));
        transactionsPanel.setBackground(Color.WHITE);
        transactionsPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            "My Transaction History",
            0,
            0,
            new Font("Arial", Font.BOLD, 16)
        ));
        
        // Table
        String[] columns = {"Transaction ID", "Type", "Amount", "Date", "Description"};
        transactionsModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        transactionsTable = new JTable(transactionsModel);
        transactionsTable.setRowHeight(25);
        transactionsTable.setFont(new Font("Arial", Font.PLAIN, 12));
        transactionsTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        
        JScrollPane scrollPane = new JScrollPane(transactionsTable);
        transactionsPanel.add(scrollPane, BorderLayout.CENTER);
        
        // Button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.WHITE);
        JButton refreshButton = new JButton("Refresh");
        refreshButton.setBackground(new Color(149, 165, 166));
        refreshButton.setForeground(Color.BLACK);
        refreshButton.setFont(new Font("Arial", Font.BOLD, 12));
        refreshButton.setFocusPainted(false);
        refreshButton.addActionListener(e -> loadData());
        buttonPanel.add(refreshButton);
        transactionsPanel.add(buttonPanel, BorderLayout.NORTH);
        
        // Container for profile and transactions
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BorderLayout(10, 10));
        contentPanel.add(profilePanel, BorderLayout.NORTH);
        contentPanel.add(transactionsPanel, BorderLayout.CENTER);
        
        // Add to main panel
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(contentPanel, BorderLayout.CENTER);
        
        add(mainPanel);
    }
    
    private void loadData() {
        // Update profile info
        nameLabel.setText(currentMember.getFullName());
        memberIdLabel.setText(currentMember.getMemberId());
        membershipTypeLabel.setText(currentMember.getMembershipType());
        
        boolean isActive = currentMember.isActive();
        statusLabel.setText(isActive ? "Active" : "Expired");
        statusLabel.setForeground(isActive ? new Color(46, 204, 113) : new Color(231, 76, 60));
        
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("MMMM dd, yyyy");
        expiryLabel.setText(sdf.format(currentMember.getMembershipExpiry()));
        
        // Load transactions
        transactionsModel.setRowCount(0);
        ArrayList<Transaction> transactions = dataManager.getTransactionsByMember(currentMember.getMemberId());
        
        for (Transaction t : transactions) {
            transactionsModel.addRow(new Object[]{
                t.getTransactionId(),
                t.getTransactionType(),
                "₱" + String.format("%.2f", t.getAmount()),
                t.getFormattedDate(),
                t.getDescription()
            });
        }
    }
    
    private void logout() {
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to logout?",
            "Confirm Logout",
            JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            LoginFrame loginFrame = new LoginFrame();
            loginFrame.setVisible(true);
            this.dispose();
        }
    }
}
