package traingate.main;

import traingate.gui.LoginFrame;
import javax.swing.*;

/**
 * TrainGateApp - Main application entry point.
 * Launches the gym management system.
 * 
 * @author Kurt Ezekiel F. Flores
 * @course CIT 508-IT21S3 - Object-Oriented Programming
 * @project TrainGate - Gym Membership and Transaction Processing System
 */
public class TrainGateApp {
    public static void main(String[] args) {
        // Set look and feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // Run GUI on Event Dispatch Thread
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                LoginFrame loginFrame = new LoginFrame();
                loginFrame.setVisible(true);
            }
        });
    }
}
