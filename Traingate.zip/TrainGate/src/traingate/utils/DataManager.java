package traingate.utils;

import traingate.models.*;
import java.util.HashMap;
import java.util.ArrayList;

/**
 * DataManager class manages all data using HashMap and ArrayList.
 * It loads data from and saves data to a MySQL database via DatabaseManager.
 */
public class DataManager {
    // HashMap for O(1) member lookup by ID (in-memory cache)
    private HashMap<String, Member> members;
    
    // ArrayList for storing transactions (in-memory cache)
    private ArrayList<Transaction> transactions;
    
    // Admin user (single admin for simplicity)
    private Admin admin;
    
    // Singleton instance
    private static DataManager instance;
    
    private DataManager() {
        // Create default admin (used for fallback login check)
        admin = new Admin("admin", "admin123", "System Administrator", "ADM001");
        
        // Load data from DATABASE
        loadData();
    }
    
    public static DataManager getInstance() {
        if (instance == null) {
            instance = new DataManager();
        }
        return instance;
    }
    
    // Member operations
    public boolean addMember(Member member) {
        if (members.containsKey(member.getMemberId())) {
            return false; // Member ID already exists
        }
        
        // 1. Add to database
        if (DatabaseManager.addMember(member)) {
            // 2. If successful, add to local cache
            members.put(member.getMemberId(), member);
            return true;
        }
        return false; // Database add failed
    }
    
    public Member getMember(String memberId) {
        return members.get(memberId);
    }
    
    public Member getMemberByUsername(String username) {
        for (Member member : members.values()) {
            if (member.getUsername().equals(username)) {
                return member;
            }
        }
        return null;
    }
    
    public ArrayList<Member> getAllMembers() {
        return new ArrayList<>(members.values());
    }
    
    public boolean deleteMember(String memberId) {
        if (!members.containsKey(memberId)) {
            return false; // Member not found
        }
        
        // 1. Delete from database
        // (The "ON DELETE CASCADE" in the SQL will auto-delete transactions)
        if (DatabaseManager.deleteMember(memberId)) {
            // 2. If successful, remove from local cache
            members.remove(memberId);
            
            // 3. ALSO remove their transactions from the local cache
            // This is what fixes your revenue bug!
            transactions.removeIf(t -> t.getMemberId().equals(memberId));
            
            return true;
        }
        return false; // Database delete failed
    }
    
    /**
     * New method to update perks in the DB and local cache.
     */
    public boolean updateMemberPerks(Member member) {
        if (DatabaseManager.updateMemberPerks(member)) {
            // Re-fetch or update the member in the local 'members' HashMap
            members.put(member.getMemberId(), member);
            return true;
        }
        return false;
    }
    
    // Transaction operations
    public boolean addTransaction(Transaction transaction) {
        // 1. Add to database
        if (DatabaseManager.addTransaction(transaction)) {
            // 2. If successful, add to local cache
            transactions.add(transaction);
            return true;
        }
        return false; // Database add failed
    }
    
    public ArrayList<Transaction> getAllTransactions() {
        return new ArrayList<>(transactions);
    }
    
    public ArrayList<Transaction> getTransactionsByMember(String memberId) {
        ArrayList<Transaction> memberTransactions = new ArrayList<>();
        for (Transaction t : transactions) {
            if (t.getMemberId().equals(memberId)) {
                memberTransactions.add(t);
            }
        }
        return memberTransactions;
    }
    
    // Admin operations
    public Admin getAdmin() {
        return admin;
    }
    
    public boolean validateAdminLogin(String username, String password) {
        // Check against the database
        Admin dbAdmin = DatabaseManager.loadAdmin(username);
        if (dbAdmin != null) {
            return dbAdmin.getPassword().equals(password);
        }
        // Fallback check (optional, or just return false)
        return admin.getUsername().equals(username) && 
               admin.getPassword().equals(password);
    }
    
    public boolean validateMemberLogin(String username, String password) {
        Member member = getMemberByUsername(username);
        // This check works as-is because it uses the in-memory cache
        return member != null && member.getPassword().equals(password);
    }
    
    // Generate unique IDs (these are fine as-is)
    public String generateMemberId() {
        int maxId = 1000;
        for (String id : members.keySet()) {
            if (id.startsWith("MEM")) {
                try {
                    int num = Integer.parseInt(id.substring(3));
                    if (num > maxId) {
                        maxId = num;
                    }
                } catch (NumberFormatException e) {
                    // Skip invalid IDs
                }
            }
        }
        return String.format("MEM%04d", maxId + 1);
    }
    
    public String generateTransactionId() {
        // A better way for databases, but this is okay for now
        long dbCount = transactions.size(); // Approximation
        return String.format("TXN%08d", dbCount + 1);
    }
    
    // Calculate total revenue (works as-is, uses local cache)
    public double calculateTotalRevenue() {
        double total = 0;
        for (Transaction t : transactions) {
            if (t.getTransactionType().equals("Payment") || 
                t.getTransactionType().equals("Renewal")) {
                total += t.getAmount();
            }
        }
        return total;
    }
    
    // Load data from DATABASE
    private void loadData() {
        try {
            // Load from DatabaseManager instead of FileHandler
            members = DatabaseManager.loadMembers();
            transactions = DatabaseManager.loadTransactions();
            
            if (members.isEmpty()) {
                System.out.println("No members found in database. Starting fresh.");
            }
            
        } catch (Exception e) {
            System.err.println("FATAL ERROR: Could not connect to database.");
            e.printStackTrace();
            // Initialize as empty to prevent app from crashing
            members = new HashMap<>();
            transactions = new ArrayList<>();
        }
    }
}