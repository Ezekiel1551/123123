package traingate.utils;

import traingate.models.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;

public class DatabaseManager {

	// --- !! IMPORTANT: UPDATE THESE FOR YOUR MYSQL SETUP !! ---
	private static final String DB_URL = "jdbc:mysql://localhost:3306/traingate_db";
	private static final String DB_USER = "root";
	private static final String DB_PASS = "your_password"; // <-- CHANGE THIS
    // Get a connection to the database
	
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
    }

    // --- Member Operations ---

    public static HashMap<String, Member> loadMembers() {
        HashMap<String, Member> members = new HashMap<>();
        String sql = "SELECT * FROM members";
        
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                // Use the simple "loading" constructor
                Member member = new Member(
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("fullName"),
                    rs.getString("memberId"),
                    rs.getString("contactNumber"),
                    rs.getString("membershipType")
                );
                
                // Now, set all other fields using setters
                member.setMembershipStart(new java.util.Date(rs.getLong("membershipStart")));
                member.setMembershipExpiry(new java.util.Date(rs.getLong("membershipExpiry")));
                member.setActive(rs.getBoolean("isActive"));
                
                // Set new perk fields
                member.setMembershipTier(rs.getString("membershipTier"));
                member.setHas247Access(rs.getBoolean("has247Access"));
                member.setPtSessionsRemaining(rs.getInt("ptSessionsRemaining"));
                member.setBodyCompositionScansRemaining(rs.getInt("bodyCompositionScansRemaining"));
                member.setHasMealPlanDiscount(rs.getBoolean("hasMealPlanDiscount"));
                
                members.put(member.getMemberId(), member);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return members;
    }

    public static boolean addMember(Member member) {
        // This SQL query now includes all the new fields
        String sql = "INSERT INTO members (memberId, username, password, fullName, " +
                     "contactNumber, membershipType, membershipStart, membershipExpiry, isActive, " +
                     "membershipTier, has247Access, ptSessionsRemaining, bodyCompositionScansRemaining, hasMealPlanDiscount) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, member.getMemberId());
            ps.setString(2, member.getUsername());
            ps.setString(3, member.getPassword());
            ps.setString(4, member.getFullName());
            ps.setString(5, member.getContactNumber());
            ps.setString(6, member.getMembershipType());
            ps.setLong(7, member.getMembershipStart().getTime());
            ps.setLong(8, member.getMembershipExpiry().getTime());
            ps.setBoolean(9, member.isActive());
            
            // Add new perk fields
            ps.setString(10, member.getMembershipTier());
            ps.setBoolean(11, member.has247Access());
            ps.setInt(12, member.getPtSessionsRemaining());
            ps.setInt(13, member.getBodyCompositionScansRemaining());
            ps.setBoolean(14, member.hasMealPlanDiscount());
            
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace(); // This is where the error log will appear in your console
            return false;
        }
    }
    
    /**
     * New method to update only the perks of a member.
     */
    public static boolean updateMemberPerks(Member member) {
        String sql = "UPDATE members SET " +
                     "ptSessionsRemaining = ?, " +
                     "bodyCompositionScansRemaining = ?, " +
                     "has247Access = ?, " +
                     "hasMealPlanDiscount = ?, " +
                     "membershipTier = ? " +
                     "WHERE memberId = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, member.getPtSessionsRemaining());
            ps.setInt(2, member.getBodyCompositionScansRemaining());
            ps.setBoolean(3, member.has247Access());
            ps.setBoolean(4, member.hasMealPlanDiscount());
            ps.setString(5, member.getMembershipTier());
            ps.setString(6, member.getMemberId());
            
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean deleteMember(String memberId) {
        // This logic is unchanged. "ON DELETE CASCADE" in SQL handles transactions.
        String sql = "DELETE FROM members WHERE memberId = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, memberId);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // --- Transaction Operations (Unchanged) ---

    public static ArrayList<Transaction> loadTransactions() {
        ArrayList<Transaction> transactions = new ArrayList<>();
        String sql = "SELECT * FROM transactions";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                Transaction t = new Transaction(
                    rs.getString("transactionId"),
                    rs.getString("memberId"),
                    rs.getString("transactionType"),
                    rs.getDouble("amount"),
                    rs.getString("description")
                );
                t.setTransactionDate(new java.util.Date(rs.getLong("transactionDate")));
                transactions.add(t);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return transactions;
    }

    public static boolean addTransaction(Transaction t) {
        String sql = "INSERT INTO transactions (transactionId, memberId, transactionType, " +
                     "amount, transactionDate, description) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, t.getTransactionId());
            ps.setString(2, t.getMemberId());
            ps.setString(3, t.getTransactionType());
            ps.setDouble(4, t.getAmount());
            ps.setLong(5, t.getTransactionDate().getTime());
            ps.setString(6, t.getDescription());
            
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // --- Admin Operations (Unchanged) ---

    public static Admin loadAdmin(String username) {
        String sql = "SELECT * FROM admin WHERE username = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Admin(
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("fullName"),
                        rs.getString("adminId")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null; // Admin not found
    }
}