#!/bin/bash
# Compile script for TrainGate application

echo "Compiling TrainGate..."
mkdir -p bin
find src -name "*.java" > sources.txt
javac -d bin @sources.txt

if [ $? -eq 0 ]; then
    echo "Compilation successful!"
    echo "Run with: java -cp bin traingate.main.TrainGateApp"
else
    echo "Compilation failed!"
    exit 1
fi
