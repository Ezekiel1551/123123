#!/bin/bash
# Run script for TrainGate application

echo "Starting TrainGate..."
java -cp bin traingate.main.TrainGateApp
