# TrainGate - Gym Membership and Transaction Processing System

## Project Overview
A Java Swing GUI-based desktop application for managing gym memberships and transactions. Created for CIT 508-IT21S3 Object-Oriented Programming Final Project.

**Student:** Kurt Ezekiel F. Flores  
**Course:** CIT 508-IT21S3 - Object-Oriented Programming  
**Institution:** Technological Institute of the Philippines, Manila

## Purpose
TrainGate automates gym management processes including:
- Member registration and authentication
- Membership transaction processing
- Transaction history tracking
- Admin and member dashboards

## Technology Stack
- **Language:** Java SE 8+
- **GUI Framework:** Java Swing (javax.swing)
- **Data Structures:** HashMap, ArrayList
- **Persistence:** File I/O (text files)

## Project Structure
```
src/traingate/
├── models/        # Data model classes (Member, Admin, Transaction, MembershipType)
├── gui/           # Swing GUI frames and panels
├── utils/         # Helper classes (DataManager, FileHandler)
└── main/          # Main application entry point
data/              # Storage for members and transactions
```

## OOP Concepts Demonstrated
1. **Encapsulation** - Private fields with getters/setters
2. **Inheritance** - Admin and Member extend User base class
3. **Polymorphism** - Method overriding in subclasses
4. **Abstraction** - Clear separation of concerns
5. **File Handling** - Java I/O streams for persistence
6. **Exception Handling** - Input validation and error management

## Data Structures Used
- **HashMap<String, Member>** - Fast O(1) member lookup by ID
- **ArrayList<Transaction>** - Dynamic list of all transactions
- Easy to explain and demonstrate in presentations

## Default Credentials
- **Admin:** username=`admin`, password=`admin123`
- **Members:** Register new members through the registration form

## How to Run
1. **In Replit:** The workflow "TrainGate App" runs automatically
2. **In Eclipse:** 
   - Import project
   - Right-click TrainGateApp.java → Run As → Java Application
3. **Command Line:** `./run.sh` or `java -cp bin traingate.main.TrainGateApp`

## Key Files
- **Models:** User.java (base), Member.java, Admin.java, Transaction.java
- **Utils:** DataManager.java (HashMap/ArrayList), FileHandler.java (I/O)
- **GUI:** LoginFrame, AdminDashboard, MemberDashboard, RegisterMemberFrame
- **Main:** TrainGateApp.java

## Last Updated
October 28, 2025 - Initial implementation complete
